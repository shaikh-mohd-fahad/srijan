import React from 'react'

function BuyCourse() {
  return (
    <div>
      buy course
    </div>
  )
}

export default BuyCourse
