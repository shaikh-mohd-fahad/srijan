import React from 'react'
import Navbar from './include/Navbar'
import Sidebar from './include/Sidebar'
import Layout from './layout/Layout'
function Dashboard() {
  return (
    <Layout>
            <h1>Welcome to the user Dashboard</h1>
    </Layout>
  )
}

export default Dashboard
