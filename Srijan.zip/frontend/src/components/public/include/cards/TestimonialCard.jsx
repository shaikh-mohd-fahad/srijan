import React from 'react'

function TestimonialCard() {
  return (
    <div>
      
    </div>
  )
}

export default TestimonialCard
