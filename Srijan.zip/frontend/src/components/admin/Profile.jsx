import React from 'react'
import Layout from './layout/Layout'

function Profile() {
  return (
    <Layout>
            <div className='container mx-auto mt-4'>
            <h1 className='text-2xl font-bold text-center'>Welcome to the Admin Profile</h1>
            </div>
    </Layout>
  )
}

export default Profile
