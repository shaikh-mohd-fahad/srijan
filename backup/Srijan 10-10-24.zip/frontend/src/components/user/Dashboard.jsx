import React from 'react'

function Dashboard() {
  return (
    <div>
      user dashbaoard
    </div>
  )
}

export default Dashboard
