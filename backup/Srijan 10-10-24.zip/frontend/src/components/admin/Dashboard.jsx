import React from 'react'

function Dashboard() {
  return (
    <div>
      <a href="/admin/allcourse/" className='btn btn-secondary'>Courses</a>
    </div>
  )
}

export default Dashboard
