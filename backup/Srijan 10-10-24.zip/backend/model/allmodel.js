import {studentModel} from "./student.js"
// console.log(studentModel)