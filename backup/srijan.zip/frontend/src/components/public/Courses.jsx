import React from 'react'
import Navbar from './include/Navbar'
import Footer from './include/Footer'
import Signup from './Signup'

function Courses() {
  return (
    <>
    {/* <Navbar/>
    <Footer/> */}
    <Signup/>
    </>
  )
}

export default Courses
